# Web app for prediction sort of wine in real time

How to use?

1. install streamlit, pandas,  sklearn using pip install, or pycharm
2. Type streamlit run <name_of_file>.py
3. if it didn't load automatically just tap your local host:
Example:
Local URL: http://localhost:8501

